from os import path
home_dir = path.expanduser('~')

 
