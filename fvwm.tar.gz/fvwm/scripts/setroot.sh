#!/bin/bash

hsetroot -tile $1 -brightness -.1

